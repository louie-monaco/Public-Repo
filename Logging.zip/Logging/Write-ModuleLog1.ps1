<#
    .SYNOPSIS
        Centralized, module-scoped logging. Portable across modules.

    .DESCRIPTION
        CONTRACT:
          1. Orchestrator calls Initialize-ModuleLog ONCE at the top of a run.
          2. Every function calls Write-ModuleLog — resolves to the same file.
          3. Standalone calls (no Initialize) fall back to a date-only log.

        CONSOLE GATING:
          - INFO, SUCCESS, WARN, ERROR, DRYRUN → always displayed.
          - DEBUG → only displayed when caller uses -Verbose.
          - SEPARATOR → always displayed (visual breaks).
          - File receives ALL severities, always.
#>

# Module-scoped log path is declared in .psm1 and set by Initialize-ModuleLog.

function Initialize-ModuleLog {
    <#
    .SYNOPSIS
        Locks the log file path for the current run. Call ONCE per orchestrator.
    .PARAMETER ModuleName
        Friendly name for the log filename.
    .PARAMETER LogDirectory
        Optional override. Defaults to <ModuleRoot>\Logs.
    .PARAMETER PassThru
        Returns the resolved log file path.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$ModuleName,
        [Parameter()][string]$LogDirectory,
        [switch]$PassThru
    )

    if ([string]::IsNullOrWhiteSpace($LogDirectory)) {
        $moduleRoot   = Split-Path -Parent $PSScriptRoot
        $LogDirectory = Join-Path $moduleRoot 'Logs'
    }

    if (-not (Test-Path -Path $LogDirectory -PathType Container)) {
        try   { New-Item -ItemType Directory -Path $LogDirectory -Force | Out-Null }
        catch { throw "Initialize-ModuleLog: Failed to create '$LogDirectory': $($_.Exception.Message)" }
    }

    $timestamp = Get-Date -Format 'yyyy-MM-dd-HHmmss'
    $fileName  = "$timestamp - $ModuleName.log"
    $script:ModuleLogPath = Join-Path $LogDirectory $fileName

    $header = @(
        '================================================================='
        "  Log Initialized : $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"
        "  Module          : $ModuleName"
        "  Host            : $($env:COMPUTERNAME)"
        "  User            : $($env:USERDOMAIN)\$($env:USERNAME)"
        "  PID             : $PID"
        "  PowerShell      : $($PSVersionTable.PSVersion)"
        '================================================================='
    )
    $header | Add-Content -Path $script:ModuleLogPath -Encoding UTF8 -ErrorAction Stop

    if ($PassThru) { return $script:ModuleLogPath }
}


function Write-ModuleLog {
    <#
    .SYNOPSIS
        Timestamped, severity-coded log entry to console and file.
    .PARAMETER Message
        Log message text.
    .PARAMETER Severity
        INFO, SUCCESS, WARN, ERROR, DEBUG, DRYRUN, SEPARATOR.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory, Position = 0)][string]$Message,
        [Parameter()][ValidateSet('INFO','SUCCESS','WARN','ERROR','DEBUG','DRYRUN','SEPARATOR')][string]$Severity = 'INFO'
    )

    # Resolve: module-scoped > date-only fallback.
    $targetPath = $null
    if (-not [string]::IsNullOrWhiteSpace($script:ModuleLogPath)) {
        $targetPath = $script:ModuleLogPath
    } else {
        $moduleRoot = Split-Path -Parent $PSScriptRoot
        $logDir     = Join-Path $moduleRoot 'Logs'
        if (-not (Test-Path -Path $logDir -PathType Container)) {
            try   { New-Item -ItemType Directory -Path $logDir -Force | Out-Null }
            catch { Write-Warning "Write-ModuleLog: Could not create fallback log dir: $($_.Exception.Message)" }
        }
        $targetPath = Join-Path $logDir "$(Get-Date -Format 'yyyy-MM-dd') - Standalone.log"
    }

    # Format.
    $timestamp = Get-Date -Format 'yyyy-MM-dd HH:mm:ss.fff'
    $logEntry  = if ($Severity -eq 'SEPARATOR') { "[$timestamp] $Message" }
                 else { "[$timestamp] [$($Severity.PadRight(7))] $Message" }

    # Console — DEBUG gated on -Verbose, everything else always shown.
    $colorMap = @{
        INFO = 'Cyan'; SUCCESS = 'Green'; WARN = 'Yellow'; ERROR = 'Red'
        DEBUG = 'DarkCyan'; DRYRUN = 'Magenta'; SEPARATOR = 'DarkGray'
    }

    if ($Severity -eq 'DEBUG') {
        if ($VerbosePreference -eq 'Continue') { Write-Host $logEntry -ForegroundColor $colorMap[$Severity] }
    } else {
        Write-Host $Message -ForegroundColor $colorMap[$Severity]
    }

    # File — all severities always written.
    try   { Add-Content -Path $targetPath -Value $logEntry -Encoding UTF8 -ErrorAction Stop }
    catch { Write-Warning "Write-ModuleLog: Failed to write to '$targetPath': $($_.Exception.Message)" }
}


function Get-ModuleLogPath {
    <# .SYNOPSIS Returns the current module-scoped log file path, or $null. #>
    [CmdletBinding()] param()
    return $script:ModuleLogPath
}
