<#
   .SYNOPSIS
      Centralized logging function for the Invoke-NTXpcAPITools module.

   .DESCRIPTION
      Writes timestamped, severity-coded log entries to both the console and a flat-text
      log file. Automatically creates the Logs directory if it does not exist.
      Log file format: YYYY-MM-DD-HH-mm - invoke-ntxpcapitools.log
      If no LogPath is provided, resolves to <ModuleRoot>\Logs\<date>-invoke-ntxpcapitools.log

      DEBUG severity is always written to the log file but is suppressed from console
      output by default. Pass -Verbose to Invoke-NTXpcAPITools to show DEBUG lines on
      console (sets $VerbosePreference = 'Continue' for the call scope).

   .PARAMETER Message
      The message to log.

   .PARAMETER Severity
      Log level. Valid: INFO, SUCCESS, WARN, ERROR, DEBUG, DRYRUN. Default: INFO.

   .PARAMETER LogPath
      Full path to target log file. Uses module-relative Logs directory if omitted.

   .EXAMPLE
      Write-NTXpcAPIToolsLog "Starting provisioning workflow" -Severity INFO

   .EXAMPLE
      Write-NTXpcAPIToolsLog "[s038-apprism01.ds.ad.ssmhc.com] Session created" -Severity SUCCESS -LogPath $logPath
#>

function Write-NTXpcAPIToolsLog {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory, Position = 0)]
        [string]$Message,

        [Parameter()]
        [ValidateSet('INFO', 'SUCCESS', 'WARN', 'ERROR', 'DEBUG', 'DRYRUN')]
        [string]$Severity = 'INFO',

        [Parameter()]
        [string]$LogPath
    )

    $timestamp = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
    $logEntry  = "[$timestamp] [$($Severity.PadRight(7))] $Message"

    $colorMap = @{
        INFO    = 'Cyan'
        SUCCESS = 'Green'
        WARN    = 'Yellow'
        ERROR   = 'Red'
        DEBUG   = 'DarkCyan'
        DRYRUN  = 'Magenta'
    }

    # DEBUG lines are always written to the log file (below) but only printed to
    # console when -Verbose is active. All other severities always print to console.
    if ($Severity -ne 'DEBUG' -or $VerbosePreference -eq 'Continue') {
        Write-Host $logEntry -ForegroundColor $colorMap[$Severity]
    }

    # Resolve Log Path: Module-relative Logs folder if not provided.
    # $PSScriptRoot here = <ModuleRoot>\Private; go up one level to reach module root.
    if ([string]::IsNullOrWhiteSpace($LogPath)) {
        $moduleRoot = Split-Path -Parent $PSScriptRoot
        $LogPath    = Join-Path $moduleRoot "Logs\$(Get-Date -Format 'yyyy-MM-dd-HHmmss') - Invoke-NTXpcAPITools.log"
    }

    # Ensure Logs directory exists.
    $logDir = Split-Path -Parent $LogPath
    if (-not (Test-Path -Path $logDir -PathType Container)) {
        try {
            New-Item -ItemType Directory -Path $logDir -Force | Out-Null
        } catch {
            Write-Warning "Write-NTXpcAPIToolsLog: Could not create log directory '$logDir': $($_.Exception.Message)"
            return
        }
    }

    # Append to log file.
    try {
        Add-Content -Path $LogPath -Value $logEntry -Encoding UTF8 -ErrorAction Stop
    } catch {
        Write-Warning "Write-NTXpcAPIToolsLog: Could not write to '$LogPath': $($_.Exception.Message)"
    }
}
