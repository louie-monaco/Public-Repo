<#
    .SYNOPSIS
        Centralized logging for the NTX-VMModify module.

    .DESCRIPTION
        Provides Initialize-ModuleLog, Write-ModuleLog, and Get-ModuleLogPath.

        CONTRACT:
          1. Orchestrator calls Initialize-ModuleLog ONCE at the top of a run.
          2. Every function calls Write-ModuleLog — it resolves to the same file.
          3. Standalone calls (no Initialize) fall back to a date-only log file.

        STRICT MODE: Inherited from module scope (Version 3.0 in .psm1).
        Do NOT set Set-StrictMode in these functions.
#>

function Initialize-ModuleLog {
    <#
    .SYNOPSIS
        Locks the log file path for the current run. Call ONCE per orchestrator.

    .PARAMETER ModuleName
        Friendly name for the log filename (e.g., 'NTX-VMModify').

    .PARAMETER LogDirectory
        Optional override for the log directory. Defaults to <ModuleRoot>\Logs.

    .PARAMETER PassThru
        Returns the resolved log file path.

    .EXAMPLE
        $logFile = Initialize-ModuleLog -ModuleName 'NTX-VMModify' -PassThru
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$ModuleName,

        [Parameter()]
        [string]$LogDirectory,

        [switch]$PassThru
    )

    if ([string]::IsNullOrWhiteSpace($LogDirectory)) {
        $moduleRoot   = Split-Path -Parent $PSScriptRoot
        $LogDirectory = Join-Path $moduleRoot 'Logs'
    }

    if (-not (Test-Path -Path $LogDirectory -PathType Container)) {
        try {
            New-Item -ItemType Directory -Path $LogDirectory -Force | Out-Null
        } catch {
            throw "Initialize-ModuleLog: Failed to create log directory '$LogDirectory': $($_.Exception.Message)"
        }
    }

    $timestamp = Get-Date -Format 'yyyy-MM-dd-HHmmss'
    $fileName  = "$timestamp - $ModuleName.log"
    $script:ModuleLogPath = Join-Path $LogDirectory $fileName

    $header = @(
        '======================================================='
        "  Log Initialized : $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"
        "  Module          : $ModuleName"
        "  Host            : $($env:COMPUTERNAME)"
        "  User            : $($env:USERDOMAIN)\$($env:USERNAME)"
        "  PID             : $PID"
        "  PowerShell      : $($PSVersionTable.PSVersion)"
        '======================================================='
    )
    $header | Add-Content -Path $script:ModuleLogPath -Encoding UTF8 -ErrorAction Stop

    if ($PassThru) { return $script:ModuleLogPath }
}


function Write-ModuleLog {
    <#
    .SYNOPSIS
        Writes a timestamped, severity-coded log entry to console and file.

    .PARAMETER Message
        The log message text.

    .PARAMETER Severity
        Log level: INFO, SUCCESS, WARN, ERROR, DEBUG, DRYRUN, SEPARATOR.

    .PARAMETER LogPath
        Optional per-call override. Use sparingly.

    .EXAMPLE
        Write-ModuleLog 'Starting disk resize' -Severity INFO

    .EXAMPLE
        Write-ModuleLog 'Current: 50GB, Requested: 100GB' -Severity DEBUG
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory, Position = 0)]
        [string]$Message,

        [Parameter()]
        [ValidateSet('INFO', 'SUCCESS', 'WARN', 'ERROR', 'DEBUG', 'DRYRUN', 'SEPARATOR')]
        [string]$Severity = 'INFO',

        [Parameter()]
        [string]$LogPath
    )

    # Resolve Target: Explicit Override > Module-Scoped > Date-Only Fallback
    $targetPath = $null

    if (-not [string]::IsNullOrWhiteSpace($LogPath)) {
        $targetPath = $LogPath
    } elseif (-not [string]::IsNullOrWhiteSpace($script:ModuleLogPath)) {
        $targetPath = $script:ModuleLogPath
    } else {
        $moduleRoot = Split-Path -Parent $PSScriptRoot
        $logDir     = Join-Path $moduleRoot 'Logs'
        if (-not (Test-Path -Path $logDir -PathType Container)) {
            try   { New-Item -ItemType Directory -Path $logDir -Force | Out-Null }
            catch { Write-Warning "Write-ModuleLog: Could not create fallback log directory '$logDir': $($_.Exception.Message)" }
        }
        $targetPath = Join-Path $logDir "$(Get-Date -Format 'yyyy-MM-dd') - Standalone.log"
    }

    # Format
    $timestamp = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
    if ($Severity -eq 'SEPARATOR') {
        $logEntry = "[$timestamp] $Message"
    } else {
        $logEntry = "[$timestamp] [$($Severity.PadRight(7))] $Message"
    }

    # Console - DEBUG Gated On -Verbose
    $colorMap = @{
        INFO = 'Cyan'; SUCCESS = 'Green'; WARN = 'Yellow'; ERROR = 'Red'
        DEBUG = 'DarkCyan'; DRYRUN = 'Magenta'; SEPARATOR = 'DarkGray'
    }

    if ($Severity -eq 'DEBUG') {
        if ($VerbosePreference -eq 'Continue') {
            Write-Host $logEntry -ForegroundColor $colorMap[$Severity]
        }
    } else {
        Write-Host $logEntry -ForegroundColor $colorMap[$Severity]
    }

    # File - All Severities Always Written
    try {
        Add-Content -Path $targetPath -Value $logEntry -Encoding UTF8 -ErrorAction Stop
    } catch {
        Write-Warning "Write-ModuleLog: Failed to write to '$targetPath': $($_.Exception.Message)"
    }
}


function Get-ModuleLogPath {
    <#
    .SYNOPSIS
        Returns the current module-scoped log file path, or $null if not initialized.
    #>
    [CmdletBinding()]
    param()
    return $script:ModuleLogPath
}
